package hr.java.projekt_srgrgic.records;
import hr.java.projekt_srgrgic.enumerations.City;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

public record Location(String location, City city) implements Serializable {

        @Override
        public String toString() {
            return location + ", " + city.getCity();
        }

        public static String getCity(String location) {
            List<String> arr = Arrays.stream(location.split(", ")).toList();
            return arr.get(arr.size() - 1);
        }

        public static Location createLocation(String locationString) {
            String location = locationString.substring(0, locationString.length() - getCity(locationString).length() - 2);
            City locationCity = City.valueOf(Location.getCity(locationString).toUpperCase());

            return new Location(location, locationCity);
        }
}

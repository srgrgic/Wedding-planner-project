package hr.java.projekt_srgrgic.listcells;

import hr.java.projekt_srgrgic.HelloApplication;
import hr.java.projekt_srgrgic.controllers.VenueCellController;
import hr.java.projekt_srgrgic.entity.Venue;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ListCell;

import java.io.IOException;

public class VenueTableRow extends ListCell<Venue> {

    @Override
    protected void updateItem(Venue venue, boolean empty) {
        super.updateItem(venue, empty);
        if (empty) {
            setText(null);
            setGraphic(null);
        } else {
            FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("venue-cell.fxml"));
            VenueCellController controller = new VenueCellController(venue);
            loader.setController(controller);
            setText(null);
            try {
                setGraphic(loader.load());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

}

package hr.java.projekt_srgrgic.utils;
import hr.java.projekt_srgrgic.entity.Organizer;
import hr.java.projekt_srgrgic.entity.Reservation;
import hr.java.projekt_srgrgic.entity.User;
import hr.java.projekt_srgrgic.entity.Venue;

import java.util.ArrayList;
import java.util.List;

public class DataWrapper {


    private List<User> userList;
    private List<Organizer> organizerList;
    private List<Venue> venueList;
    private List<Reservation> reservationList;

    public DataWrapper() {
        userList = new ArrayList<>();
        organizerList = new ArrayList<>();
        venueList = new ArrayList<>();
        reservationList = new ArrayList<>();
    }


    public DataWrapper(DataWrapper dataWrapper) {
        this.userList = new ArrayList<>(dataWrapper.userList);
        this.organizerList = new ArrayList<>(dataWrapper.organizerList);
        this.venueList = new ArrayList<>(dataWrapper.venueList);
        this.reservationList = new ArrayList<>(dataWrapper.reservationList);
    }

    public List<User> getUserList() {
        return userList;
    }

    public void setUserList(List<User> userList) {
        this.userList = userList;
    }

    public List<Organizer> getOrganizerList() {
        return organizerList;
    }

    public void setOrganizerList(List<Organizer> organizerList) {
        this.organizerList = organizerList;
    }

    public List<Venue> getVenueList() {
        return venueList;
    }

    public void setVenueList(List<Venue> venueList) {
        this.venueList = venueList;
    }

    public List<Reservation> getReservationList() {
        return reservationList;
    }

    public void setReservationList(List<Reservation> reservationList) {
        this.reservationList = reservationList;
    }


}

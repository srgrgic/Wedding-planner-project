package hr.java.projekt_srgrgic.sorter;


import hr.java.projekt_srgrgic.entity.Venue;

import java.util.Comparator;

public class VenueCostSorter implements Comparator<Venue> {

    @Override
    public int compare(Venue v1, Venue v2) {
        return v1.getPricePerSeat().compareTo(v2.getPricePerSeat());
    }
}

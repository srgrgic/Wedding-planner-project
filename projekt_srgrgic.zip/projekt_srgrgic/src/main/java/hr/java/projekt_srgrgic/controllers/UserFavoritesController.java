package hr.java.projekt_srgrgic.controllers;

import hr.java.projekt_srgrgic.database.Database;
import hr.java.projekt_srgrgic.entity.Account;
import hr.java.projekt_srgrgic.entity.User;
import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.exceptions.DatabaseException;
import hr.java.projekt_srgrgic.listcells.VenueCellFactory;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;

import java.io.IOException;
import java.util.List;

public class UserFavoritesController extends Controller{

    private User currentUser;

    @FXML
    private TableView<Venue> venueTableView;

    @FXML
    private Button unlikeButton;

    @FXML
    private Button detailsButton;


    @Override
    public void passAccount(Account account) {
        this.currentUser = (User) account;
        List<Venue> venueList;
        try {
            venueList = Database.getFavoriteVenues(currentUser);
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }

        venueTableView.setRowFactory(new VenueCellFactory());
        venueTableView.getItems().addAll(venueList);
    }

    @Override
    public void passVenue(Venue venue) {}

    public void initialize() {
        unlikeButton.setVisible(false);
        detailsButton.setVisible(false);
    }

    public void removeFromFavorites() {
        Venue selectedVenue = venueTableView.getSelectionModel().getSelectedItem();
        List<Venue> venueList;
        try {
            Database.removeFavouriteVenue(currentUser, selectedVenue);
            venueList = Database.getFavoriteVenues(currentUser);
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }

        venueTableView.getItems().clear();
        venueTableView.setRowFactory(new VenueCellFactory());
        venueTableView.getItems().addAll(venueList);
    }

    public void showVenue() {
        Venue selectedVenue = venueTableView.getSelectionModel().getSelectedItem();
        if (selectedVenue != null) {
            try {
                MenuController.showVenueScreen("venue-user-perspective.fxml", "Detaljno", 1030, 750, currentUser, selectedVenue);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void showButtons() {
        unlikeButton.setVisible(true);
        detailsButton.setVisible(true);
    }
}

package hr.java.projekt_srgrgic.controllers;

import hr.java.projekt_srgrgic.entity.User;
import hr.java.projekt_srgrgic.entity.Venue;
import javafx.fxml.FXML;
import javafx.scene.text.Text;
import hr.java.projekt_srgrgic.entity.Account;

public class UserProfileController extends Controller{

    private User currentUser;

    @FXML
    private Text testLabel;

    public void passAccount(Account account) {
        this.currentUser = (User) account;
        testLabel.setText(currentUser.getSurname());
    }

    @Override
    public void passVenue(Venue venue) {}

}

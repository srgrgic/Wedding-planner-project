package hr.java.projekt_srgrgic.files;


import hr.java.projekt_srgrgic.HelloApplication;
import hr.java.projekt_srgrgic.encryptor.Encryptor;
import hr.java.projekt_srgrgic.exceptions.PasswordFileException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.NoSuchAlgorithmException;
import java.util.List;


public class PasswordFile {

    public static boolean logInCheck(String username, String encryptedPassword, String accountType) {
        try (BufferedReader in = new BufferedReader(new FileReader("dat/accounts.txt"))) {
            List<String> stringList = in.lines().toList();
            for (int i = 0; i < stringList.size(); i += 3) {
                if (username.equals(stringList.get(i)) && encryptedPassword.equals(stringList.get(i + 1)) &&
                        accountType.equals(stringList.get(i + 2))) {
                    return true;
                }
            }
        } catch (IOException e) {
            HelloApplication.logger.error("Pogreška pri radu s datotekom.");
            throw new PasswordFileException();
        }

        return false;
    }

    public static boolean usernameExists(String username) {
        try (BufferedReader in = new BufferedReader(new FileReader("dat/accounts.txt"))) {
            List<String> stringList = in.lines().toList();
            for (int i = 0; i < stringList.size(); i += 3) {
                if (username.equals(stringList.get(i))) {
                    return true;
                }
            }
        } catch (IOException e) {
            HelloApplication.logger.error("Pogreška pri radu s datotekom.");
            throw new PasswordFileException();
        }

        return false;
    }

    public static void writeNewAccount(String username, String password, String accountType) {
        String encryptedPassword;
        try {
            encryptedPassword = Encryptor.encryptString(password);
        } catch (NoSuchAlgorithmException e) {
            HelloApplication.logger.error("Pogreška pri hashiranju lozinke.");
            throw new RuntimeException(e);
        }

        Path accountData = Path.of("dat/accounts.txt");
        try {
            Files.writeString(accountData, username + "\n", StandardOpenOption.APPEND);
            Files.writeString(accountData, encryptedPassword + "\n", StandardOpenOption.APPEND);
            Files.writeString(accountData, accountType + "\n", StandardOpenOption.APPEND);
        }
        catch (IOException e) {
            HelloApplication.logger.error("Pogreška pri radu s datotekom.");
            throw new PasswordFileException();
        }
    }


}

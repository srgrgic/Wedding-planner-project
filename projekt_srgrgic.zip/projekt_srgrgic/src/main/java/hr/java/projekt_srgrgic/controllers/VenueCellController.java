package hr.java.projekt_srgrgic.controllers;

import hr.java.projekt_srgrgic.database.Database;
import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.exceptions.DatabaseException;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.text.Text;

public class VenueCellController {

    private final Venue venue;

    @FXML
    private Label nameLabel;

    @FXML
    private Text venueTypeLabel;

    @FXML
    private Label numberOfFavoritesLabel;

    @FXML
    private Label locationLabel;

    public VenueCellController(Venue venue) {
        this.venue = venue;
    }

    public void initialize() {
        nameLabel.setText(venue.toString());
        locationLabel.setText(venue.getLocation().toString());
        venueTypeLabel.setText(venue.getVenueType().toString().toUpperCase());
        String labelColor = "-fx-fill: " + venue.getVenueType().getLabelColor();
        venueTypeLabel.setStyle(labelColor);

        int numberOfFavorites;
        try {
            numberOfFavorites = Database.getNumberOfFavorites(this.venue);
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }
        numberOfFavoritesLabel.setText(numberOfFavorites + " zainteresiranih");

    }
}

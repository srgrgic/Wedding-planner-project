package hr.java.projekt_srgrgic.threads;

import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.exceptions.DatabaseException;
import hr.java.projekt_srgrgic.database.Database;
import hr.java.projekt_srgrgic.files.SerializationFile;

import java.io.IOException;
import java.util.List;

public class FirstThread implements Runnable{



    @Override
    public void run() {
        List<Venue> venueList=null;
        try {
            venueList = Database.getVenues();
        } catch (DatabaseException e) {
            System.out.println("Nije uspelo!");
        }

        Venue mostFavoritedVenue = null;
        int mostLikes = 0;
        for (Venue venue : venueList) {
            int likes;
            try {
                likes = Database.getNumberOfFavorites(venue);
            } catch (DatabaseException e) {
                throw new RuntimeException(e);
            }
            if (likes > mostLikes) {
                mostLikes = likes;
                mostFavoritedVenue = venue;
            }
        }

        try {
            SerializationFile.serialize(mostFavoritedVenue);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }



}

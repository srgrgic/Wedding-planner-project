package hr.java.projekt_srgrgic.entity;

import hr.java.projekt_srgrgic.records.Location;


import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

public class Organizer extends Account implements Serializable {

    private String name;
    private Location location;
    private String eMail;
    private String phoneNumber;
    private List<Venue> venueList;


    public Organizer(Long id, String username, LocalDate creationDate, String name, Location location, String eMail, String phoneNumber) {
        super(id, username, creationDate);
        this.name = name;
        this.location = location;
        this.eMail = eMail;
        this.phoneNumber = phoneNumber;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Location getAddress() {
        return location;
    }

    public void setAddress(Location address) {
        this.location = location;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public List<Venue> getVenueList() {
        return venueList;
    }

    public void setVenueList(List<Venue> venueList) {
        this.venueList = venueList;
    }




}

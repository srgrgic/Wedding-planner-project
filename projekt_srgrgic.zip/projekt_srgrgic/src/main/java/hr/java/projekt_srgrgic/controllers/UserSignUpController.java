package hr.java.projekt_srgrgic.controllers;

import hr.java.projekt_srgrgic.HelloApplication;
import hr.java.projekt_srgrgic.database.Database;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import hr.java.projekt_srgrgic.entity.Account;
import hr.java.projekt_srgrgic.entity.User;
import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.exceptions.DatabaseException;
import hr.java.projekt_srgrgic.exceptions.InvalidInputException;
import hr.java.projekt_srgrgic.files.PasswordFile;

import java.io.IOException;
import java.time.LocalDate;

import static hr.java.projekt_srgrgic.HelloApplication.logger;

public class UserSignUpController extends Controller{


    private final String accountType = "user";

    @FXML
    private TextField usernameTextField;

    @FXML
    private TextField nameTextField;

    @FXML
    private TextField surnameTextField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private PasswordField repeatedPasswordField;

    @FXML
    private Text infoLabel;

    public void cancel() throws IOException {
        MenuController.showScreen("login.fxml", "Prijava i registracija", 600, 400, null);
    }

    public void invalidInput() throws InvalidInputException {
        if (usernameTextField.getText().isBlank() || nameTextField.getText().isBlank() || surnameTextField.getText().isBlank() ||
                passwordField.getText().isBlank() || repeatedPasswordField.getText().isBlank()) {
            throw new InvalidInputException("Molim popunite sva polja!");
        }
        if (PasswordFile.usernameExists(usernameTextField.getText())) {
            throw new InvalidInputException("Korisničko ime je zauzeto!");
        }
        if (passwordField.getText().equals(repeatedPasswordField.getText()) == false) {
            throw new InvalidInputException("Lozinke se ne podudaraju!");
        }
        if (passwordField.getText().length() < 8) {
            throw new InvalidInputException("Lozinka mora sadržavati minimalno 8 znakova!");
        }
    }

    public void createNewAccount() throws IOException {
        String username = usernameTextField.getText();
        String password = passwordField.getText();

        try {
            invalidInput();
        } catch (InvalidInputException e) {
            infoLabel.setText(e.getMessage());
            logger.info(e.getMessage());
            return;
        }

        PasswordFile.writeNewAccount(username, password, accountType);

        User user = new User(null, username, nameTextField.getText(), surnameTextField.getText(), LocalDate.now());
        User refreshedUser;
        try {
            Database.inputUsers(user);
            refreshedUser = Database.filterUsers(user).get(0);
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }

        MenuController.showScreen("user-venues.fxml", "Hello!", 1030, 750, refreshedUser);
    }


    @Override
    public void passAccount(Account account) {}

    @Override
    public void passVenue(Venue venue) {}
}




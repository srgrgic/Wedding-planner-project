package hr.java.projekt_srgrgic.listcells;

import hr.java.projekt_srgrgic.entity.Venue;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.util.Callback;


public class VenueCellFactory implements Callback<TableView<Venue>, TableRow<Venue>> {

    @Override
    public TableRow<Venue> call(TableView<Venue> param) {
        return new TableRow<>();
    }
}

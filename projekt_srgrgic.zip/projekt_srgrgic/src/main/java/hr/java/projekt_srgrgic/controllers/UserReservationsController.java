package hr.java.projekt_srgrgic.controllers;

import hr.java.projekt_srgrgic.entity.Reservation;
import hr.java.projekt_srgrgic.entity.User;
import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.exceptions.DatabaseException;
import hr.java.projekt_srgrgic.generics.Changes;
import hr.java.projekt_srgrgic.utils.AlertWindow;
import hr.java.projekt_srgrgic.utils.ChangeWrapper;
import hr.java.projekt_srgrgic.utils.FileUtils;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import hr.java.projekt_srgrgic.database.Database;

import java.util.List;

public class UserReservationsController {

    @FXML
    private Button cancelReservationButton;

    @FXML
    private ListView<Reservation> reservationListView;

    private User currentUser;

    public void initialize() {
        loadReservations();
        configureReservationSelection();
        cancelReservationButton.setOnAction(e -> cancelSelectedReservation());
    }

    public void loadReservations() {
        try {
            List<Reservation> reservations = Database.getUserReservations(currentUser.getId());
            reservationListView.setItems(FXCollections.observableArrayList(reservations));
        } catch (DatabaseException e) {
            AlertWindow.showNotificationDialog("Greška", "Ne mogu se učitati rezervacije.");
        }
    }

    public void configureReservationSelection() {
        reservationListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
    }

    public void cancelSelectedReservation() {
        Reservation selectedReservation = reservationListView.getSelectionModel().getSelectedItem();
        if (selectedReservation != null) {
            try {
                Database.cancelReservation(selectedReservation.getId());
                loadReservations();
                User userWhoCancelled = Database.getUserById(selectedReservation.getUserId());
                Venue venueForReservation = Database.getVenueById(selectedReservation.getVenueId());
                ChangeWrapper changeWrapper = FileUtils.readDataChangeFromFile();
                Changes<User, Venue> reservationCancelledChange = new Changes<>(userWhoCancelled, venueForReservation);
                changeWrapper.addDataChange(reservationCancelledChange);
                FileUtils.writeDataChangeToFile(changeWrapper);

                AlertWindow.showNotificationDialog("Otkazivanje rezervacije", "Rezervacija je uspješno otkazana.");
            } catch (DatabaseException e) {
                AlertWindow.showNotificationDialog("Greška", "Rezervacija nije mogla biti otkazana.");
            }
        } else {
            AlertWindow.showNotificationDialog("Odabir rezervacije", "Molimo odaberite rezervaciju koju želite otkazati.");
        }
    }







}

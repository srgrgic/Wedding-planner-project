package hr.java.projekt_srgrgic.exceptions;

public class PasswordFileException extends RuntimeException {

    public PasswordFileException() {
    }

    public PasswordFileException(String message) {
        super(message);
    }

    public PasswordFileException(String message, Throwable cause) {
        super(message, cause);
    }

    public PasswordFileException(Throwable cause) {
        super(cause);
    }

    public PasswordFileException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }



}

package hr.java.projekt_srgrgic.utils;

import hr.java.projekt_srgrgic.HelloApplication;
import hr.java.projekt_srgrgic.entity.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class FileUtils {

    private static final Logger logger = LoggerFactory.getLogger(HelloApplication.class);
    private static final String DATA_BIN_FILE_NAME = "dat/data.bin";
    private static final String DATA_CHANGES_BIN_FILE_NAME = "dat/dataChanges.bin";

    public static void writeDataToFile(DataWrapper dataWrapper) {
        try
        {
            FileOutputStream file = new FileOutputStream(DATA_BIN_FILE_NAME);
            ObjectOutputStream out = new ObjectOutputStream(file);

            out.writeObject(dataWrapper);
            out.close();
            file.close();
            System.out.println("Serijalizacija uspjela DataWrapper");

        }
        catch(IOException ex)
        {
            System.out.println("IOException is caught");
        }
    }

    public static Optional<DataWrapper> readDataFromFile() {
        Optional<DataWrapper> dataWrapperOptional = Optional.empty();
        try
        {
            FileInputStream file = new FileInputStream(DATA_BIN_FILE_NAME);
            ObjectInputStream in = new ObjectInputStream(file);

            DataWrapper dataWrapper;
            dataWrapper = (DataWrapper) in.readObject();
            dataWrapperOptional = Optional.of(dataWrapper);
            in.close();
            file.close();
            System.out.println("DeSerijalizacija uspjela DataWrapper");

        }
        catch(IOException ex)
        {
            System.out.println("IOException is caught");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return dataWrapperOptional;
    }

    public static void writeDataChangeToFile(ChangeWrapper changeWrapper) {
        try
        {
            FileOutputStream file = new FileOutputStream(DATA_CHANGES_BIN_FILE_NAME);
            ObjectOutputStream out = new ObjectOutputStream(file);

            out.writeObject(changeWrapper);
            out.close();
            file.close();
            System.out.println("Serijalizacija uspjela DataChangeWrapper");

        }
        catch(IOException ex)
        {
            System.out.println("IOException is caught");
        }
    }


    public static ChangeWrapper readDataChangeFromFile() {
        ChangeWrapper changeWrapper = new ChangeWrapper(new ArrayList<>());
        try
        {
            FileInputStream file = new FileInputStream(DATA_CHANGES_BIN_FILE_NAME);
            ObjectInputStream in = new ObjectInputStream(file);

            changeWrapper = (ChangeWrapper) in.readObject();
            in.close();
            file.close();
            System.out.println("DeSerijalizacija uspjela DataChangeWrapper");

        }
        catch(IOException ex)
        {
            System.out.println("IOException is caught");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return changeWrapper;
    }

}

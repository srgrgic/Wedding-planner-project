package hr.java.projekt_srgrgic.controllers;

import hr.java.projekt_srgrgic.database.Database;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import hr.java.projekt_srgrgic.entity.Account;
import hr.java.projekt_srgrgic.entity.User;
import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.enumerations.City;
import hr.java.projekt_srgrgic.enumerations.VenueType;
import hr.java.projekt_srgrgic.exceptions.DatabaseException;
import hr.java.projekt_srgrgic.listcells.VenueCellFactory;
import hr.java.projekt_srgrgic.records.Location;
import hr.java.projekt_srgrgic.sorter.VenueCostSorter;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

public class UserVenuesController extends Controller{

    private User currentUser;

    @FXML
    private ChoiceBox<VenueType> venueTypeChoiceBox;

    @FXML
    private DatePicker dateDatePicker;

    @FXML
    private ChoiceBox<City> cityChoiceBox;

    @FXML
    private TextField guestsTextField;


    @FXML
    private TableView<Venue> venuesTableView;

    @FXML
    private TableColumn<Venue, String> nameColumn;

    @FXML
    private TableColumn<Venue, String> organizerColumn;

    @FXML
    private TableColumn<Venue, String> locationColumn;

    @FXML
    private TableColumn<Venue, VenueType> venueTypeColumn;

    @FXML
    private Button likeButton;


    @Override
    public void passAccount(Account account) {
        this.currentUser = (User) account;
    }

    @Override
    public void passVenue(Venue venue) {}

    public void initialize() {
        List<Venue> venueList=getVenueListSortedByPrice();
        try {
            venueList = Database.getVenues();
            populateTableView(venueList);
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }


        venuesTableView.setRowFactory(new VenueCellFactory());
        venuesTableView.getItems().addAll(venueList);

        venueTypeChoiceBox.getItems().addAll(VenueType.values());

        cityChoiceBox.getItems().addAll(City.values());

        likeButton.setVisible(false);

        venuesTableView.getItems().setAll(venueList);
    }

    public void search() {
        VenueType venueType = venueTypeChoiceBox.getSelectionModel().getSelectedItem();
        City city = cityChoiceBox.getSelectionModel().getSelectedItem();
        LocalDate date = dateDatePicker.getValue();

        Venue venue = new Venue(null, null, new Location("", city), null, null, null, null, null, null);
        List<Venue> venueList;
        try {
            venueList = Database.filterVenues(venue);
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }

        venuesTableView.getItems().clear();
        venuesTableView.refresh();
        venuesTableView.setRowFactory(new VenueCellFactory());
        venuesTableView.getItems().addAll(venueList);
    }

    public void showLikeButton() {
        Venue selectedVenue = venuesTableView.getSelectionModel().getSelectedItem();
        try {
            if (Database.venueFavouriteCheck(currentUser, selectedVenue)) {
                likeButton.setVisible(false);
            }
            else {
                likeButton.setVisible(true);
            }
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }
    }

    public void markAsFavourite() {
        Venue selectedVenue = venuesTableView.getSelectionModel().getSelectedItem();

        try {
            Database.insertFavouriteVenue(currentUser, selectedVenue);
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }
        likeButton.setVisible(false);
        venuesTableView.refresh();
    }

    public void showVenue() {
        Venue selectedVenue = venuesTableView.getSelectionModel().getSelectedItem();
        LocalDate selectedDate = dateDatePicker.getValue();
        if (selectedVenue != null) {
            try {
                MenuController.showVenueScreen("venue-user-perspective.fxml", "Detaljno", 1030, 750, currentUser, selectedVenue);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void populateTableView(List<Venue> venueList) {
        nameColumn.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getName()));
        organizerColumn.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getOrganizer().getName()));
        locationColumn.setCellValueFactory(cellData -> new ReadOnlyStringWrapper(cellData.getValue().getLocation().toString()));
        venueTypeColumn.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getVenueType()));
        venuesTableView.getItems().setAll(venueList);
    }

    private List<Venue> getVenueListSortedByPrice() {
        List<Venue> venueList;
        try {
            venueList = Database.getVenues();
            venueList.sort(new VenueCostSorter());
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }
        return venueList;
    }

}

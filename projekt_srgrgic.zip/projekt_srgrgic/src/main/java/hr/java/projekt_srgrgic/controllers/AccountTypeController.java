package hr.java.projekt_srgrgic.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import hr.java.projekt_srgrgic.entity.Account;
import hr.java.projekt_srgrgic.entity.Venue;

import java.io.IOException;

public class AccountTypeController extends Controller{

    @FXML
    private Button nextButton;

    private boolean organizator = false;

    private boolean korisnik = false;

    public void showLoginScreen() throws IOException {
        MenuController.showScreen("login.fxml", "Hello!", 600, 400, null);
    }

    public void initialize() {
        nextButton.setDisable(true);
    }

    public void showNext() throws IOException {
        if (organizator) {
            MenuController.showScreen("organizator-sign-up.fxml", "Registriraj se!", 600, 475, null);
        } else if (korisnik) {
            MenuController.showScreen("sign-up-user.fxml", "Registriraj se!", 600, 430, null);
        }
    }

    public void odaberiOrganizator() {
        nextButton.setDisable(false);
        organizator = true;
        korisnik = false;
    }

    public void odaberiKorisnik() {
        nextButton.setDisable(false);
        korisnik = true;
        organizator = false;
    }

    @Override
    public void passAccount(Account account) {}

    @Override
    public void passVenue(Venue venue) {}


}

package hr.java.projekt_srgrgic.generics;

import hr.java.projekt_srgrgic.entity.Organizer;
import hr.java.projekt_srgrgic.entity.User;
import hr.java.projekt_srgrgic.entity.Venue;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Changes <TFirst,TSecond> implements Serializable {

    TFirst data1;
    TSecond data2;
    LocalDateTime time;

    public Changes(TFirst data1, TSecond data2) {
        this.data1 = data1;
        this.data2 = data2;
        time = LocalDateTime.now();
    }

    @Override
    public String toString() {
        DateTimeFormatter dateTimeFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String formattedDateTime = time.format(dateTimeFormat);
        if (data2 instanceof String) {
            return data1 + " " + data2 + " " + formattedDateTime;
        }
        else if (data1 instanceof Organizer && data2 instanceof Venue) {
            return data1 + " je dodao prostor:" + data2 + " " + formattedDateTime;
        }
        else if (data1 instanceof Venue && data2 instanceof Organizer) {
            return data1 + " je obrisao prostor:" + data2 + " " + formattedDateTime;
        }
        else if (data1 instanceof User && data2 instanceof Venue) {
            return data1 + " je napravio rezervaciju za: " + data2 + " " + formattedDateTime;
        }
        else if (data1 instanceof Venue && data2 instanceof User) {
            return data2 + " je otkazao rezervaciju za: " + data1 + " " + formattedDateTime;
        }
        else return data1 + " - " + data2 + " " + formattedDateTime;
    }

}

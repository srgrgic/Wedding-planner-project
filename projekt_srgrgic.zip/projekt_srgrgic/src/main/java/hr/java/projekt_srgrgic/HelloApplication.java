package hr.java.projekt_srgrgic;

import hr.java.projekt_srgrgic.threads.SecondThread;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import hr.java.projekt_srgrgic.threads.FirstThread;

public class HelloApplication extends Application {

    private static Stage mainStage;

    public static final Logger logger = LoggerFactory.getLogger(HelloApplication.class);
    @Override
    public void start(Stage stage) throws IOException {
        mainStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 400);
        stage.setResizable(false);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();

        Timeline calculatingMostFavoritedVenue = new Timeline( new KeyFrame(Duration.seconds(5),
                event -> Platform.runLater(new FirstThread())));
        calculatingMostFavoritedVenue.setCycleCount(Timeline.INDEFINITE);
        calculatingMostFavoritedVenue.play();
        Timeline showingMostFavoritedVenue = new Timeline( new KeyFrame(Duration.seconds(7),
                event -> Platform.runLater(new SecondThread())));
        showingMostFavoritedVenue.setCycleCount(Timeline.INDEFINITE);
        showingMostFavoritedVenue.play();
    }
    public static void main(String[] args) {
        launch();
    }

    public static Stage getStage() {
        return mainStage;
    }
}
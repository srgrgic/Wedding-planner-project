package hr.java.projekt_srgrgic.controllers;

import hr.java.projekt_srgrgic.HelloApplication;
import hr.java.projekt_srgrgic.utils.ChangeWrapper;
import hr.java.projekt_srgrgic.utils.FileUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;

public class ChangesViewController {

    private static final Logger logger = LoggerFactory.getLogger(HelloApplication.class);

    @FXML
    ListView<String> changesListView;
    private ChangeWrapper changeWrapper;

    public void initialize() {
        changeWrapper = FileUtils.readDataChangeFromFile();
        List<String> changeStringList = changeWrapper.getStringifiedChanges();
        ObservableList<String> observableChangeStringList = FXCollections.observableArrayList(changeStringList);
        changesListView.setItems(observableChangeStringList);
    }

    public void switchToOrganizerVenues() {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("organizer-venues.fxml"));
        Scene scene = null;
        try {
            scene = new Scene(fxmlLoader.load(), 800, 500);
        } catch (IOException e) {
            e.printStackTrace();
        }
        logger.info("Prebačeno na organizer-venues");
        HelloApplication.mainStage.setScene(scene);
        HelloApplication.mainStage.show();
    }


}

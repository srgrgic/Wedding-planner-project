package hr.java.projekt_srgrgic.controllers;

import hr.java.projekt_srgrgic.entity.Account;
import hr.java.projekt_srgrgic.entity.Venue;

public class OrganizatorProfileController extends Controller {


    @Override
    public void passAccount(Account account) {

    }

    @Override
    public void passVenue(Venue venue) {

    }
}

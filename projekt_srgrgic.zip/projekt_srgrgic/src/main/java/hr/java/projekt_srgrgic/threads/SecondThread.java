package hr.java.projekt_srgrgic.threads;

import hr.java.projekt_srgrgic.HelloApplication;
import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.files.SerializationFile;

import java.io.IOException;

public class SecondThread implements Runnable{

    @Override
    public void run() {

        Venue mostFavoritedVenue=null;
        try {
            mostFavoritedVenue = SerializationFile.deserialize();
        } catch (IOException e) {
            System.out.println("Nije uspjelo!");
        }
        if (mostFavoritedVenue != null) {
            HelloApplication.getStage().setTitle("Najpoželjniji prostor: " + mostFavoritedVenue);
        }

    }


}

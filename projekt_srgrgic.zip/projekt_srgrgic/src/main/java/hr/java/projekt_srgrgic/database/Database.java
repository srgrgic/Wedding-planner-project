package hr.java.projekt_srgrgic.database;
import hr.java.projekt_srgrgic.HelloApplication;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import hr.java.projekt_srgrgic.entity.Organizer;
import hr.java.projekt_srgrgic.entity.User;
import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.enumerations.VenueType;
import hr.java.projekt_srgrgic.exceptions.DatabaseException;
import hr.java.projekt_srgrgic.records.Location;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.util.*;


public class Database {

    private static final Logger logger = LoggerFactory.getLogger(HelloApplication.class);

    public static Connection connectToDB() throws Exception{

        Properties configuration = new Properties();
        configuration.load(new FileInputStream("dat/database.properties"));

        Connection connection = DriverManager.getConnection(
                configuration.getProperty("databaseURL"),
                configuration.getProperty("username"),
                configuration.getProperty("password"));
        return connection;
    }


    public static List<User> getUsers() throws DatabaseException {
        List<User> userList = new ArrayList<>();
        try (Connection connection = connectToDB()) {
            Statement stmt = connection.createStatement();
            ResultSet resultSet = stmt.executeQuery("SELECT * FROM APP_USER");
            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String username = resultSet.getString("username");
                String name = resultSet.getString("name");
                String surname = resultSet.getString("surname");
                LocalDate creationDate = resultSet.getDate("creation_date").toLocalDate();
                User newUser = new User(id, username, name, surname, creationDate);
                userList.add(newUser);
            }
        } catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }

        return userList;

    }


    public static List<User> filterUsers(User user) throws DatabaseException{
        List<User> userList = new ArrayList<>();
        try (Connection connection = connectToDB()) {
            StringBuilder sqlQuery = new StringBuilder("SELECT * FROM APP_USER WHERE 1 = 1");
            if (Optional.ofNullable(user).isEmpty() == false) {
                if (Optional.ofNullable(user).map(User::getId).isPresent()) {
                    sqlQuery.append(" AND ID = " + user.getId());
                }
                if (Optional.ofNullable(user.getUsername()).map(String::isBlank).orElse(true) == false) {
                    sqlQuery.append(" AND USERNAME LIKE '%" + user.getUsername() + "%'");
                }
                if (Optional.ofNullable(user.getName()).map(String::isBlank).orElse(true) == false) {
                    sqlQuery.append(" AND NAME LIKE '%" + user.getName() + "%'");
                }
                if (Optional.ofNullable(user.getSurname()).map(String::isBlank).orElse(true) == false) {
                    sqlQuery.append(" AND SURNAME LIKE '%" + user.getSurname() + "%'");
                }
                if (user.getCreationDate() != null) {
                    sqlQuery.append(" AND CREATION_DATE LIKE '%" + user.getCreationDate() + "%'");
                }
            }

            Statement query = connection.createStatement();

            ResultSet resultSet = query.executeQuery(sqlQuery.toString());

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String username = resultSet.getString("username");
                String name = resultSet.getString("name");
                String surname = resultSet.getString("surname");
                LocalDate creationDate = resultSet.getDate("creation_date").toLocalDate();
                User newUser = new User(id, username, name, surname, creationDate);
                userList.add(newUser);
            }
        }

        catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }
        return userList;


    }


    public static void inputUsers(User user) throws DatabaseException{
        try (Connection connection = connectToDB()) {
            PreparedStatement preparedStatement = connection.prepareStatement( "INSERT INTO APP_USER(username, name, surname, creation_date) VALUES (?, ?, ?, ?)");
            preparedStatement.setString(1, user.getUsername());
            preparedStatement.setString(2, user.getName());
            preparedStatement.setString(3, user.getSurname());
            preparedStatement.setString(4, user.getCreationDate().toString());
            preparedStatement.executeUpdate();
        } catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }

    }

    public static List<Organizer> getOrganizers() throws DatabaseException{
        List<Organizer> organizerList = new ArrayList<>();
        try (Connection connection = connectToDB()) {
            Statement stmt = connection.createStatement();
            ResultSet resultSet = stmt.executeQuery("SELECT * FROM ORGANIZATOR");
            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String username = resultSet.getString("username");
                String name = resultSet.getString("name");
                Location address = Location.createLocation(resultSet.getString("address"));
                String email = resultSet.getString("email");
                String phoneNumber = resultSet.getString("phone_number");
                LocalDate creationDate = resultSet.getDate("creation_date").toLocalDate();
                Organizer newOrganizer = new Organizer(id, username, creationDate, name, address, email, phoneNumber);
                organizerList.add(newOrganizer);
            }
        } catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }

        return organizerList;

    }

    public static List<Organizer> filterOrganizers(Organizer organizer) throws DatabaseException{
        List<Organizer> organizerList = new ArrayList<>();
        try (Connection connection = connectToDB()) {
            StringBuilder sqlQuery = new StringBuilder("SELECT * FROM ORGANIZATOR WHERE 1 = 1");
            if (Optional.ofNullable(organizer).isEmpty() == false) {
                if (Optional.ofNullable(organizer).map(Organizer::getId).isPresent()) {
                    sqlQuery.append(" AND ID = " + organizer.getId());
                }
                if (Optional.ofNullable(organizer.getUsername()).map(String::isBlank).orElse(true) == false) {
                    sqlQuery.append(" AND USERNAME LIKE '%" + organizer.getUsername() + "%'");
                }
                if (Optional.ofNullable(organizer.getName()).map(String::isBlank).orElse(true) == false) {
                    sqlQuery.append(" AND NAME LIKE '%" + organizer.getName() + "%'");
                }
                if (organizer.getAddress() != null) {
                    sqlQuery.append(" AND ADDRESS LIKE '%" + organizer.getAddress() + "%'");
                }
                if (Optional.ofNullable(organizer.geteMail()).map(String::isBlank).orElse(true) == false) {
                    sqlQuery.append(" AND EMAIL LIKE '%" + organizer.geteMail() + "%'");
                }
                if (Optional.ofNullable(organizer.getPhoneNumber()).map(String::isBlank).orElse(true) == false) {
                    sqlQuery.append(" AND PHONE_NUMBER LIKE '%" + organizer.getPhoneNumber() + "%'");
                }
                if (organizer.getCreationDate() != null) {
                    sqlQuery.append(" AND CREATION_DATE LIKE '%" + organizer.getCreationDate() + "%'");
                }
            }

            Statement query = connection.createStatement();

            ResultSet resultSet = query.executeQuery(sqlQuery.toString());

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String username = resultSet.getString("username");
                String name = resultSet.getString("name");
                Location address = Location.createLocation(resultSet.getString("address"));
                String email = resultSet.getString("email");
                String phoneNumber = resultSet.getString("phone_number");
                LocalDate creationDate = resultSet.getDate("creation_date").toLocalDate();
                Organizer newOrganizer = new Organizer(id, username, creationDate, name, address, email, phoneNumber);
                organizerList.add(newOrganizer);
            }
        }

        catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }
        return organizerList;


    }


    public static void inputOrganizers (Organizer organizer) throws DatabaseException{
        try (Connection connection = connectToDB()) {
            PreparedStatement preparedStatement = connection.prepareStatement( "INSERT INTO ORGANIZATOR(username, name, address, email, phone_number, creation_date) VALUES (?, ?, ?, ?, ?,?)");
            preparedStatement.setString(1, organizer.getUsername());
            preparedStatement.setString(2, organizer.getName());
            preparedStatement.setString(3, organizer.getAddress().toString());
            preparedStatement.setString(4, organizer.geteMail());
            preparedStatement.setString(5, organizer.getPhoneNumber());
            preparedStatement.setString(6, organizer.getCreationDate().toString());
            preparedStatement.executeUpdate();
        } catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }
    }


    public static List<Venue> getVenues() throws DatabaseException{
        List<Venue> venueList = new ArrayList<>();
        try (Connection connection = connectToDB()) {
            Statement stmt = connection.createStatement();
            ResultSet resultSet = stmt.executeQuery("SELECT * FROM VENUE");
            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                Location location = Location.createLocation(resultSet.getString("location"));
                Long organizerId = resultSet.getLong("organizer_id");
                String venueTypeString = resultSet.getString("venue_type");
                VenueType venueType = VenueType.getVenueTypeEnum(venueTypeString);
                Integer capacity= resultSet.getInt("capacity");
                BigDecimal pricePerSeat = resultSet.getBigDecimal("price_per_seat");
                String description = resultSet.getString("description");
                List<LocalDate> availableDates = getAvailableDatesForVenue(id, connection);
                Organizer organizer = filterOrganizers(new Organizer(organizerId, null, null, null, null, null, null)).get(0);
                Venue newVenue = new Venue(id, name,location,organizer, venueType, capacity, pricePerSeat, description, availableDates);
                venueList.add(newVenue);
            }
        } catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }

        return venueList;

    }

    public static List<Venue> filterVenues(Venue venue) throws DatabaseException{
        List<Venue> venueList = new ArrayList<>();
        try (Connection connection = connectToDB()) {
            StringBuilder sqlQuery = new StringBuilder("SELECT * FROM VENUE WHERE 1 = 1");
            if (Optional.ofNullable(venue).isEmpty() == false) {
                if (Optional.ofNullable(venue).map(Venue::getId).isPresent()) {
                    sqlQuery.append(" AND ID = " + venue.getId());
                }
                if (Optional.ofNullable(venue.getName()).map(String::isBlank).orElse(true) == false) {
                    sqlQuery.append(" AND NAME LIKE '%" + venue.getName() + "%'");
                }
                if (venue.getLocation() != null) {
                    if (venue.getLocation().city() != null) {
                        sqlQuery.append(" AND LOCATION LIKE '%" + venue.getLocation().city().getCity() + "%'");
                    }
                }
                if (venue.getAvailableDates() != null) {
                    sqlQuery.append(" AND DATE LIKE '%" + venue.getAvailableDates() + "%'");
                }
                if (Optional.ofNullable(venue.getOrganizer()).map(Organizer::getId).isPresent()) {
                    sqlQuery.append(" AND ORGANIZATOR_ID LIKE '%" + venue.getOrganizer().getId() + "%'");
                }
                if (Optional.ofNullable(venue.getVenueType()).map(VenueType::getVenueType).isPresent()) {
                    sqlQuery.append(" AND VENUE_TYPE LIKE '%" + venue.getVenueType() + "%'");
                }

                if (Optional.ofNullable(venue.getCapacity()).isPresent()) {
                    sqlQuery.append(" AND CAPACITY >= " + venue.getCapacity());
                }

                if (Optional.ofNullable(venue.getPricePerSeat()).isPresent()) {
                    sqlQuery.append(" AND PRICE_PER_SEAT <= " + venue.getPricePerSeat().toPlainString());
                }


            }

            Statement query = connection.createStatement();

            ResultSet resultSet = query.executeQuery(sqlQuery.toString());

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String name = resultSet.getString("name");
                Location location = Location.createLocation(resultSet.getString("location"));
                LocalDate date = resultSet.getDate("date").toLocalDate();
                Long organizerId = resultSet.getLong("organizator_id");
                String venueTypeString = resultSet.getString("venue_type");
                VenueType venueType = VenueType.getVenueTypeEnum(venueTypeString);
                Integer capacity= resultSet.getInt("capacity");
                BigDecimal pricePerSeat = resultSet.getBigDecimal("price_per_seat");
                String description = resultSet.getString("description");
                List<LocalDate> availableDates = getAvailableDatesForVenue(id, connection);
                Organizer organizer = filterOrganizers(new Organizer(organizerId, null, null, null, null, null, null)).get(0);
                Venue newVenue = new Venue(id, name,location,organizer, venueType, capacity, pricePerSeat, description, availableDates);
                venueList.add(newVenue);
            }
        }

        catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }
        return venueList;


    }


    public static void inputVenue(Venue venue) throws DatabaseException{
        try (Connection connection = connectToDB()) {
            PreparedStatement preparedStatement = connection.prepareStatement( "INSERT INTO VENUE(name, location, organizator_id, venue_type, date, capacity, price_per_seat, description) VALUES (?, ?, ?, ?, ?, ?, ?,?)");
            preparedStatement.setString(1, venue.getName());
            preparedStatement.setString(2, venue.getLocation().toString());
            preparedStatement.setString(3, venue.getOrganizer().getId().toString());
            preparedStatement.setString(4, venue.getVenueType().toString());
            preparedStatement.setString(5, venue.getAvailableDates().toString());
            preparedStatement.setString(6, venue.getCapacity().toString());
            preparedStatement.setString(7, venue.getPricePerSeat().toString());
            preparedStatement.setString(8, venue.getDescription());
            preparedStatement.executeUpdate();
        } catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }

    }

    public static void deleteVenue(Venue venue) throws DatabaseException {
        deleteFavouriteVenues(venue);
        try (Connection connection = connectToDB()) {
            String sqlQuery = "DELETE FROM VENUE WHERE ID LIKE '%"
                    + venue.getId().toString() + "%'";

            Statement query = connection.createStatement();

            query.executeUpdate(sqlQuery);
        }

        catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }
    }


    public static void deleteFavouriteVenues(Venue venue) throws DatabaseException {
        try (Connection connection = connectToDB()) {
            String sqlQuery = "DELETE FROM USER_VENUE WHERE VENUE_ID LIKE '%"
                    + venue.getId().toString() + "%'";

            Statement query = connection.createStatement();

            query.executeUpdate(sqlQuery);
        }

        catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }
    }

    public static void removeFavouriteVenue(User user, Venue venue) throws DatabaseException {
        try (Connection connection = connectToDB()) {
            String sqlQuery = "DELETE FROM USER_VENUE WHERE VENUE_ID LIKE '%"
                    + venue.getId().toString() + "%' AND APP_USER_ID LIKE '%" + user.getId().toString() + "%'";

            Statement query = connection.createStatement();

            query.executeUpdate(sqlQuery);
        }

        catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }
    }

    public static boolean venueFavouriteCheck(User user, Venue venue) throws DatabaseException {
        try (Connection connection = connectToDB()) {
            String sqlQuery = "SELECT * FROM USER_VENUE WHERE 1 = 1 AND APP_USER_ID LIKE '%"
                    + user.getId().toString() + "%' AND VENUE_ID LIKE '%"
                    + venue.getId().toString() + "%'";

            Statement query = connection.createStatement();

            ResultSet resultSet = query.executeQuery(sqlQuery);

            while (resultSet.next()) {
                return true;
            }
            return false;
        }

        catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }
    }

    public static void insertFavouriteVenue(User user, Venue venue) throws DatabaseException {
        try (Connection connection = connectToDB()) {
            PreparedStatement preparedStatement = connection.prepareStatement( "INSERT INTO USER_VENUE(app_user_id, venue_id) VALUES (?, ?)");
            preparedStatement.setString(1, user.getId().toString());
            preparedStatement.setString(2, venue.getId().toString());
            preparedStatement.executeUpdate();
        } catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }
    }


    public static List<Venue> getFavoriteVenues(User user) throws DatabaseException {
        List<Venue> venueList = new ArrayList<>();
        try (Connection connection = connectToDB()) {
            String sqlQuery = "SELECT * FROM USER_VENUE WHERE 1 = 1 AND USER_ID LIKE '%"
                    + user.getId().toString() + "%'";

            Statement query = connection.createStatement();

            ResultSet resultSet = query.executeQuery(sqlQuery);

            while (resultSet.next()) {
                Long id = resultSet.getLong("venue_id");
                Venue newVenue = Database.filterVenues(new Venue(id, null, null, null, null, null, null, null,null)).get(0);
                venueList.add(newVenue);
            }
        }

        catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }
        return venueList;
    }

    public static int getNumberOfFavorites(Venue venue) throws DatabaseException {
        int number = 0;
        try (Connection connection = connectToDB()) {
            String sqlQuery = "SELECT * FROM USER_VENUE WHERE 1 = 1 AND VENUE_ID LIKE '%"
                    + venue.getId().toString() + "%'";

            Statement query = connection.createStatement();

            ResultSet resultSet = query.executeQuery(sqlQuery);

            while (resultSet.next()) {
                number++;
            }
        }

        catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }
        return number;
    }


    public static boolean venueFavoritedCheck(User user, Venue venue) throws DatabaseException {
        try (Connection connection = connectToDB()) {
            String sqlQuery = "SELECT * FROM USER_VENUE WHERE 1 = 1 AND APP_USER_ID LIKE '%"
                    + user.getId().toString() + "%' AND VENUE_ID LIKE '%"
                    + venue.getId().toString() + "%'";

            Statement query = connection.createStatement();

            ResultSet resultSet = query.executeQuery(sqlQuery);

            while (resultSet.next()) {
                return true;
            }
            return false;
        }

        catch (Exception ex) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, ex);
            throw new DatabaseException(message, ex);
        }
    }


    public static void insertAvailableDatesForVenue(Long venueId, List<LocalDate> availableDates) throws DatabaseException {
        try (Connection connection = connectToDB();
             Statement statement = connection.createStatement()) {

            for (LocalDate date : availableDates) {
                String sql = "INSERT INTO VENUE_DATE (venue_id, available_date) VALUES (" + venueId + ", '" + Date.valueOf(date) + "')";
                statement.executeUpdate(sql);
            }

        } catch (Exception e) {
            String message = "Došlo je do pogreške u radu s bazom podataka";
            logger.error(message, e);
            throw new DatabaseException(message, e);
        }
    }


    private static List<LocalDate> getAvailableDatesForVenue(Long venueId, Connection connection) throws DatabaseException {
        List<LocalDate> dates = new ArrayList<>();
        String sql = "SELECT date FROM VENUE_DATE WHERE venue_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setLong(1, venueId);
            ResultSet resultSet = pstmt.executeQuery();
            while (resultSet.next()) {
                LocalDate date = resultSet.getDate("date").toLocalDate();
                dates.add(date);
            }
        } catch (Exception e) {
            throw new DatabaseException("Došlo je do pogreške prilikom dohvata dostupnih datuma za prostor.", e);
        }
        return dates;
    }

    public static void removeAvailableDate(Long venueId, LocalDate dateToRemove) throws DatabaseException {
        try (Connection connection = connectToDB()) {
            String sqlQuery = "DELETE FROM VENUE_DATE WHERE venue_id = " + venueId + " AND available_date = '" + dateToRemove + "'";

            Statement statement = connection.createStatement();
            int affectedRows = statement.executeUpdate(sqlQuery);

            if (affectedRows == 0) {
                throw new DatabaseException("Brisanje datuma nije uspjelo, datum možda već ne postoji.");
            }
        } catch (Exception e) {
            String message = "Došlo je do greške u radu s bazom podataka";
            logger.error(message, e);
            throw new DatabaseException(message, e);
        }
    }


}

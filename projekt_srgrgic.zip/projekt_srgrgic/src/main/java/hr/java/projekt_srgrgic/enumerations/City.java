package hr.java.projekt_srgrgic.enumerations;

public enum City {

    ZAGREB ("Zagreb"),
    SPLIT ("Split"),
    RIJEKA ("Rijeka"),
    OSIJEK ("Osijek"),
    ZADAR ("Zadar"),
    VARAŽDIN ("Varaždin"),
    KARLOVAC ("Karlovac"),
    SAMOBOR ("Samobor");

    private String city;

    City(String city) {
        this.city = city;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public static City getCityEnum(String value) {
        City cityEnum = null;
        switch (value) {
            case "Zagreb":
                cityEnum = City.ZAGREB;
            case "Split":
                cityEnum = City.SPLIT;
            case "Rijeka":
                cityEnum = City.RIJEKA;
            case "Osijek":
                cityEnum = City.OSIJEK;
            case "Zadar":
                cityEnum = City.ZADAR;
            case "Varaždin":
                cityEnum = City.VARAŽDIN;
            case "Karlovac":
                cityEnum = City.KARLOVAC;
            case "Samobor":
                cityEnum = City.SAMOBOR;
        }

        return cityEnum;
    }

    @Override
    public String toString() {
        return getCity();
    }


}

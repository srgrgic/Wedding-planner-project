package hr.java.projekt_srgrgic.controllers;

import hr.java.projekt_srgrgic.HelloApplication;
import hr.java.projekt_srgrgic.database.Database;
import hr.java.projekt_srgrgic.encryptor.Encryptor;
import hr.java.projekt_srgrgic.entity.Account;
import hr.java.projekt_srgrgic.entity.Organizer;
import hr.java.projekt_srgrgic.entity.User;
import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.exceptions.DatabaseException;
import hr.java.projekt_srgrgic.exceptions.InvalidInputException;
import hr.java.projekt_srgrgic.files.PasswordFile;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;


public class LoginController extends Controller {

    @FXML
    private ChoiceBox<String> accountTypeChoiceBox;

    @FXML
    private TextField usernameTextField;

    @FXML
    private PasswordField passwordField;


    @FXML
    private Text accessDeniedText;

    public void initialize() {
        accountTypeChoiceBox.getItems().addAll("Organizator", "Korisnik");
    }

    public void showAccountTypeScreen() throws IOException {
        MenuController.showScreen("account-type-window.fxml", "Registracija", 600, 400, null);
    }

    public void signInAction() {
        String username = usernameTextField.getText();
        String password = passwordField.getText();
        String accountType;

        try {
            invalidInput(username, password);
        } catch (InvalidInputException e) {
            accessDeniedText.setText("Molim popunite sva polja!");
            HelloApplication.logger.info(e.getMessage());
            return;
        }

        if (accountTypeChoiceBox.getSelectionModel().getSelectedItem().equals("Organizator")) {
            accountType = "organizer";
        } else {
            accountType = "user";
        }

        String encryptedPassword;
        try {
            encryptedPassword = Encryptor.encryptString(password);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        if (PasswordFile.logInCheck(username, encryptedPassword, accountType)) {
            if (accountType.equals("user")) {
                try {
                    User currentAcc = Database.filterUsers(new User(null, null, null, null, null)).get(0);
                    MenuController.showScreen("user-venues.fxml", "Dostupni prostori za vjenčanja", 1030, 750, currentAcc);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                } catch (DatabaseException e) {
                    throw new RuntimeException(e);
                }
            } else {
                try {
                    Organizer currentAcc = Database.filterOrganizers(new Organizer(null, null, null, null, null, null, null)).get(0);
                    MenuController.showScreen("organizer-venues.fxml", "Moji prostori", 1030, 750, currentAcc);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                } catch (DatabaseException e) {
                    throw new RuntimeException(e);
                }
            }
        }     else {
               accessDeniedText.setText("Pogrešna lozinka, korisničko ime ili neispravna vrsta profila!");
              }
    }

    public void invalidInput(String username, String password) throws InvalidInputException {
        if (username.isBlank() || password.isBlank() || accountTypeChoiceBox.getSelectionModel().isEmpty()) {
            throw new InvalidInputException("Molim popunite sva polja!");
        }
    }


    @Override
    public void passAccount(Account account) {}

    @Override
    public void passVenue(Venue venue) {}

}

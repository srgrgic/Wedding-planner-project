package hr.java.projekt_srgrgic.controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import hr.java.projekt_srgrgic.entity.Account;
import hr.java.projekt_srgrgic.entity.Organizer;
import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.enumerations.City;
import hr.java.projekt_srgrgic.exceptions.DatabaseException;
import hr.java.projekt_srgrgic.exceptions.InvalidInputException;
import hr.java.projekt_srgrgic.files.PasswordFile;
import hr.java.projekt_srgrgic.records.Location;
import hr.java.projekt_srgrgic.database.Database;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.stream.Collectors;

import static hr.java.projekt_srgrgic.HelloApplication.logger;

public class OrganizatorSignUpController extends Controller{

    private final String accountType = "organizer";

    @FXML
    private TextField usernameTextField;

    @FXML
    private TextField nameTextField;

    @FXML
    private TextField addressTextField;

    @FXML
    private ChoiceBox<String> cityChoiceBox;

    @FXML
    private TextField eMailTextField;

    @FXML
    private TextField phoneNumberTextField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private PasswordField repeatedPasswordField;

    @FXML
    private Text infoLabel;

    public void initialize() {
        ObservableList<String> cities = FXCollections.observableArrayList(Arrays.stream(City.values())
                .map(city -> city.getCity())
                .collect(Collectors.toList()));
        cityChoiceBox.setItems(cities);
    }

    public void cancel() throws IOException {
        MenuController.showScreen("login.fxml", "Prijava i registracija", 600, 400, null);
    }

    public void invalidInput() throws InvalidInputException {
        if (usernameTextField.getText().isBlank() || nameTextField.getText().isBlank() || addressTextField.getText().isBlank() ||
                cityChoiceBox.getSelectionModel().isEmpty() || eMailTextField.getText().isBlank() || phoneNumberTextField.getText().isBlank() ||
                passwordField.getText().isBlank() || repeatedPasswordField.getText().isBlank()) {
            throw new InvalidInputException("Molim popunite sva polja!");
        }
        if (PasswordFile.usernameExists(usernameTextField.getText())) {
            throw new InvalidInputException("Korisničko ime je zauzeto!");
        }
        if (passwordField.getText().equals(repeatedPasswordField.getText()) == false) {
            throw new InvalidInputException("Lozinke se ne podudaraju!");
        }
        if (passwordField.getText().length() < 8) {
            throw new InvalidInputException("Lozinka mora sadržavati minimalno 8 znakova!");
        }
    }

    public void createNewAccount() throws IOException {
        String username = usernameTextField.getText();
        String password = passwordField.getText();

        try {
            invalidInput();
        } catch (InvalidInputException e) {
            infoLabel.setText(e.getMessage());
            logger.info(e.getMessage());
            return;
        }

        PasswordFile.writeNewAccount(username, password, accountType);

        Location address = new Location(addressTextField.getText(), City.getCityEnum(cityChoiceBox.getSelectionModel().getSelectedItem()));
        Organizer organizer = new Organizer(null, username, LocalDate.now(), nameTextField.getText(), address, eMailTextField.getText(), phoneNumberTextField.getText());
        Organizer refreshedOrganizer;
        try {
            Database.inputOrganizers(organizer);
            refreshedOrganizer = Database.filterOrganizers(organizer).get(0);
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }

        MenuController.showScreen("organizer-venues.fxml", "Hello!", 1030, 750, refreshedOrganizer);
    }

    @Override
    public void passAccount(Account account) {}

    @Override
    public void passVenue(Venue venue) {}

}

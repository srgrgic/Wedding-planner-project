package hr.java.projekt_srgrgic.controllers;

import hr.java.projekt_srgrgic.HelloApplication;
import hr.java.projekt_srgrgic.entity.Account;
import hr.java.projekt_srgrgic.entity.Venue;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import java.io.IOException;

public class MenuController extends Controller {


    private static final int SCREEN_WIDTH = 1030;
    private static final int SCREEN_HEIGHT = 750;
    private static final int LOGIN_SCREEN_WIDTH = 600;
    private static final int LOGIN_SCREEN_HEIGHT = 400;

    private static Account currentAcc;

    public static <T extends Account> void passAccountBeetwenMenu(T account) { currentAcc = account; }

    public static <T extends Account> void showScreen(String fxmlFile, String screenTitle, int width, int height, T currentAcc) throws IOException {
        passAccountBeetwenMenu(currentAcc);
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource(fxmlFile));
        Parent root = fxmlLoader.load();
        Controller controller = fxmlLoader.getController();
        controller.passAccount(currentAcc);
        Scene scene = new Scene(root, width, height);
        HelloApplication.getStage().setTitle(screenTitle);
        HelloApplication.getStage().setScene(scene);
        HelloApplication.getStage().show();
        HelloApplication.getStage().centerOnScreen();
    }

    public void showUserVenuesScreen() throws IOException {
        showScreen("user-venues.fxml", "Dostupni prostori za vjenčanja", SCREEN_WIDTH, SCREEN_HEIGHT, currentAcc);
    }

    public void showUserFavoritesScreen() throws IOException {
        showScreen("user-favorites.fxml", "Favoriti", SCREEN_WIDTH, SCREEN_HEIGHT, currentAcc);
    }

    public  void showUserProfileScreen() throws IOException {
        showScreen("user-profile.fxml", "Moj profil", SCREEN_WIDTH, SCREEN_HEIGHT, currentAcc);
    }

    public void showOrganizerVenuesScreen() throws IOException {
        showScreen("organizer-venues.fxml", "Moji prostori", SCREEN_WIDTH, SCREEN_HEIGHT, currentAcc);
    }

    public void showVenueCreationScreen() throws IOException {
        showScreen("organizer-venue-creation.fxml", "Dodavanje prostora", SCREEN_WIDTH, SCREEN_HEIGHT, currentAcc);
    }

    public void showOrganizerProfileScreen() throws IOException {
        showScreen("organizator-profile.fxml", "Moj profil", SCREEN_WIDTH, SCREEN_HEIGHT, currentAcc);
    }

    public void logOut() throws IOException {
        showScreen("login.fxml", "Prijava i registracija", LOGIN_SCREEN_WIDTH, LOGIN_SCREEN_HEIGHT, null);
    }

    public static <T extends Account> void showVenueScreen(String fxmlFile, String screenTitle, int width, int height, T currentAcc, Venue venue) throws IOException {
        passAccountBeetwenMenu(currentAcc);
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource(fxmlFile));
        Parent root = fxmlLoader.load();
        Controller controller = fxmlLoader.getController();
        controller.passAccount(currentAcc);
        controller.passVenue(venue);
        Scene scene = new Scene(root, width, height);
        HelloApplication.getStage().setTitle(screenTitle);
        HelloApplication.getStage().setScene(scene);
        HelloApplication.getStage().show();
        HelloApplication.getStage().centerOnScreen();
    }

    @Override
    public void passAccount(Account account) {}

    @Override
    public void passVenue(Venue venue) {}
}

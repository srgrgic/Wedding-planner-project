package hr.java.projekt_srgrgic.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import hr.java.projekt_srgrgic.entity.Account;
import hr.java.projekt_srgrgic.entity.Organizer;
import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.enumerations.City;
import hr.java.projekt_srgrgic.enumerations.VenueType;
import hr.java.projekt_srgrgic.exceptions.DatabaseException;
import hr.java.projekt_srgrgic.exceptions.InvalidInputException;
import hr.java.projekt_srgrgic.records.Location;
import hr.java.projekt_srgrgic.database.Database;

import java.io.IOException;

import static hr.java.projekt_srgrgic.HelloApplication.logger;

public class OrganizatorVenueCreationController extends Controller {

    private Organizer currentOrganizer;

    @FXML
    private TextField nameTextField;

    @FXML
    private TextField locationTextField;

    @FXML
    private ChoiceBox<City> cityChoiceBox;

    @FXML
    private ChoiceBox<VenueType> venueTypeChoiceBox;

    @FXML
    private TextArea descriptionTextArea;

    @FXML
    private Text infoLabel;

    @Override
    public void passAccount(Account account) {
        currentOrganizer = (Organizer) account;
    }

    @Override
    public void passVenue(Venue venue) {}

    public void initialize() {
        venueTypeChoiceBox.getItems().addAll(VenueType.values());

        cityChoiceBox.getItems().addAll(City.values());
    }

    public void create() {
        String name = nameTextField.getText();
        String location = locationTextField.getText();
        City city = cityChoiceBox.getSelectionModel().getSelectedItem();
        VenueType venueType = venueTypeChoiceBox.getSelectionModel().getSelectedItem();
        String description = descriptionTextArea.getText();

        try {
            invalidInput(name, location, city, venueType, description);
        } catch (InvalidInputException e) {
            infoLabel.setText(e.getMessage());
            logger.info(e.getMessage());
            return;
        }

        Venue newVenue = new Venue(null, name, new Location(location, city), currentOrganizer, venueType, description);

        try {
            Database.inputVenue(newVenue);
            infoLabel.setText("Kreiranje uspjelo!");
            MenuController.showScreen("organizer-events.fxml", "Moji događaji", 1030, 750, currentOrganizer);
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void invalidInput(String name, String location, City city, VenueType venueType, String description) throws InvalidInputException {
        if (name.isBlank() || location.isBlank() || city == null || venueType== null ||
                description.isBlank()) {
            throw new InvalidInputException("Molim popunite sva polja!");
        }

    }

}

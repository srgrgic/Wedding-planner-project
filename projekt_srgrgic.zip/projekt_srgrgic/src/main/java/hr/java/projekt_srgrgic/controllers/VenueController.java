package hr.java.projekt_srgrgic.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import hr.java.projekt_srgrgic.entity.Account;
import hr.java.projekt_srgrgic.entity.User;
import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.exceptions.DatabaseException;
import hr.java.projekt_srgrgic.database.Database;

import java.math.BigDecimal;
import java.time.LocalDate;

public class VenueController extends Controller{

    private Account currentAccount;

    private Venue venueShown;

    @FXML
    private Text venueNameText;

    @FXML
    private Label venueLocationLabel;

    @FXML
    private Label venueDescriptionLabel;

    @FXML
    private Label numberOfFavoritesLabel;

    @FXML
    private Label pricePerSeatLabel;

    @FXML
    private Label capacityLabel;

    @FXML
    private TextField guestsTextField;

    @FXML
    private Button reserveButton;

    @FXML
    private Button favoriteButton;

    @FXML
    private Label totalPriceLabel;

    @FXML
    private DatePicker reservationDatePicker;

    @FXML
    private Text warningText;



    @Override
    public void passAccount(Account account) {
        currentAccount = account;
    }

    @Override
    public void passVenue(Venue venue) {
        venueShown = venue;
        venueNameText.setText(venueShown.getName());
        venueLocationLabel.setText(venueShown.getLocation().toString());
        venueDescriptionLabel.setText(venueShown.getDescription());


        try {
            numberOfFavoritesLabel.setText(Database.getNumberOfFavorites(venueShown) + " zainteresiranih");
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }

        pricePerSeatLabel.setText("Cijena po stolici:" +venueShown.getPricePerSeat().toString() + " EUR");
        capacityLabel.setText(String.valueOf("Kapacitet:" +venueShown.getCapacity()));


        if (currentAccount instanceof User currentUser) {
            try {
                if (Database.venueFavoritedCheck(currentUser, venueShown)) {
                    favoriteButton.setVisible(false);
                } else {
                    favoriteButton.setVisible(true);
                }
            } catch (DatabaseException e) {
                throw new RuntimeException();
            }
        }

    }



    public void calculatePrice() {
        String guestsText = guestsTextField.getText();
        if (!guestsText.isBlank()) {
            try {
                int numberOfGuests = Integer.parseInt(guestsText);
                BigDecimal totalPrice = venueShown.getPricePerSeat().multiply(new BigDecimal(numberOfGuests));
                totalPriceLabel.setText("Ukupna cijena: " + totalPrice + " EUR");
            } catch (NumberFormatException e) {
                totalPriceLabel.setText("Pogrešan unos broja gostiju.");
            }
        } else {
            totalPriceLabel.setText("Molimo unesite broj gostiju.");
        }
    }

    public void markAsFavorite() {
        try {
            Database.insertFavouriteVenue((User) currentAccount, venueShown);
            numberOfFavoritesLabel.setText(Database.getNumberOfFavorites(venueShown) + " zainteresiranih");
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }
        favoriteButton.setVisible(false);

    }

    @FXML
    private void markAsReserved() {
        LocalDate selectedDate = reservationDatePicker.getValue();
        if (selectedDate == null) {
            warningText.setText("Morate odabrati datum za rezervaciju.");
            return;
        }

        if (!venueShown.getAvailableDates().contains(selectedDate)) {
            warningText.setText("Datum nije dostupan");
            return;
        }

        try {
            Database.removeAvailableDate(venueShown.getId(), selectedDate);
            venueShown.getAvailableDates().remove(selectedDate);
            warningText.setText("Rezervacija uspješna");
        } catch (DatabaseException e) {
            e.printStackTrace();
            warningText.setText("Došlo je do greške prilikom rezervacije.");
        }
    }








}

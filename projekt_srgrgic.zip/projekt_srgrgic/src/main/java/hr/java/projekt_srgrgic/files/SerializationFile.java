package hr.java.projekt_srgrgic.files;

import hr.java.projekt_srgrgic.HelloApplication;
import hr.java.projekt_srgrgic.entity.Venue;
import hr.java.projekt_srgrgic.exceptions.SerializeException;

import java.io.*;

public class SerializationFile {

    private static final String FILE_NAME = "dat/most_favorites_venue.ser";

    public static synchronized void serialize(Venue venue) throws IOException {
        ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE_NAME));
        out.writeObject(venue);
        out.close();
    }

    public static synchronized Venue deserialize() throws IOException {
        ObjectInputStream in = new ObjectInputStream(new FileInputStream(FILE_NAME));
        Venue venueRead = null;
        try {
            venueRead = (Venue) in.readObject();
        } catch (ClassNotFoundException e) {
            HelloApplication.logger.error(e.getMessage());
            throw new SerializeException();
        }

        return venueRead;
    }

}

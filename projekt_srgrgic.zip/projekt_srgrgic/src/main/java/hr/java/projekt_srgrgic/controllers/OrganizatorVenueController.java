package hr.java.projekt_srgrgic.controllers;

import hr.java.projekt_srgrgic.database.Database;
import hr.java.projekt_srgrgic.entity.Account;
import hr.java.projekt_srgrgic.entity.Organizer;
import hr.java.projekt_srgrgic.entity.Venue;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import hr.java.projekt_srgrgic.enumerations.VenueType;
import hr.java.projekt_srgrgic.exceptions.DatabaseException;
import hr.java.projekt_srgrgic.listcells.VenueCellFactory;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;


public class OrganizatorVenueController extends Controller{

    private Organizer currentOrganizer;

    @FXML
    private TableView<Venue> venuesTableView;

    @FXML
    private TableColumn<Venue, String> organizerColumn;

    @FXML
    private TableColumn<Venue, String> locationColumn;

    @FXML
    private TableColumn<Venue, VenueType> typeColumn;

    @FXML
    private TableColumn<Venue, BigDecimal> pricePerSeatColumn;

    @FXML
    private Button deleteButton;

    @FXML
    private Button detailsButton;

    @Override
    public void passAccount(Account account) {
        currentOrganizer = (Organizer) account;

        List<Venue> venueList;
        try {
            venueList = Database.filterVenues(new Venue(null, null, null, null, null, null, null,null,null));
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }

        venuesTableView.setRowFactory(new VenueCellFactory());
        venuesTableView.getItems().addAll(venueList);
    }

    @Override
    public void passVenue(Venue venue) {}

    public void initialize() {
        deleteButton.setVisible(false);
        detailsButton.setVisible(false);
    }

    public void delete() {
        Venue selectedVenue = venuesTableView.getSelectionModel().getSelectedItem();
        List<Venue> refreshedVenueList;
        try {
            Database.deleteVenue(selectedVenue);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Brisanje uspjelo!");
            alert.setHeaderText("Brisanje uspjelo!");
            alert.setContentText("Prostorija je uspješno izbrisana.");
            alert.showAndWait();
            refreshedVenueList = Database.filterVenues(new Venue(null, null, null, null, null, null, null, null, null));
        } catch (DatabaseException e) {
            throw new RuntimeException(e);
        }
        venuesTableView.getItems().clear();
        venuesTableView.getItems().addAll(refreshedVenueList);
    }

    public void showVenue() {
        Venue selectedVenue = venuesTableView.getSelectionModel().getSelectedItem();
        try {
            MenuController.showVenueScreen("venue-organizer-perspective.fxml", "Detaljno", 1030, 750, currentOrganizer, selectedVenue);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void showButtons() {
        deleteButton.setVisible(true);
        detailsButton.setVisible(true);
    }
}

package hr.java.projekt_srgrgic.controllers;

import hr.java.projekt_srgrgic.entity.Account;
import hr.java.projekt_srgrgic.entity.Venue;

public abstract class Controller <T extends Account, V extends Venue>{
    public abstract void passAccount(T account);

    public abstract void passVenue(V venue);

}

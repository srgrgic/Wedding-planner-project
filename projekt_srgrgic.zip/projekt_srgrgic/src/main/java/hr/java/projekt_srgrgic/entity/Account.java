package hr.java.projekt_srgrgic.entity;

import java.time.LocalDate;

public abstract class Account extends Entity {

    private String username;
    private LocalDate creationDate;

    public Account(Long id, String username, LocalDate creationDate) {
        super(id);
        this.username = username;
        this.creationDate = creationDate;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public LocalDate getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(LocalDate creationDate) {
        this.creationDate = creationDate;
    }


}

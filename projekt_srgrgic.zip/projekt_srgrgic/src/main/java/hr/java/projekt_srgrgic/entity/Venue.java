package hr.java.projekt_srgrgic.entity;



import hr.java.projekt_srgrgic.enumerations.VenueType;
import hr.java.projekt_srgrgic.records.Location;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class Venue extends Entity {

    private String name;

    private VenueType venueType;
    private Location location;
    private Organizer organizer;
    private List<LocalDate> availableDates;
    private Integer capacity;
    private BigDecimal pricePerSeat;
    private String description;


    public Venue(Long id, String name, Location location, Organizer organizer, VenueType venueType, Integer capacity, BigDecimal pricePerSeat, String description,List<LocalDate> availableDates) {
        super(id);
        this.name = name;
        this.location = location;
        this.organizer=organizer;
        this.availableDates = availableDates;
        this.venueType=venueType;
        this.capacity = capacity;
        this.pricePerSeat = pricePerSeat;
        this.description=description;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location address) {
        this.location = location;
    }

    public Organizer getOrganizer(){return organizer;};
    public void setOrganizer(Organizer organizer){
        this.organizer=organizer;
    }


    public VenueType getVenueType(){
        return venueType;
    }
    public void setVenueType(VenueType venueType){
        this.venueType=venueType;
    }

    public List<LocalDate> getAvailableDates() {
        return availableDates;
    }

    public void setAvailableDates(List<LocalDate> availableDates) {
        this.availableDates = availableDates;
    }


    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }


    public BigDecimal getPricePerSeat() {
        return pricePerSeat;
    }

    public void setPricePerSeat(BigDecimal pricePerSeat) {
        this.pricePerSeat = pricePerSeat;
    }

    public Venue(Long id, String description, Location location, Organizer currentOrganizer, VenueType eventType, String s) {
        super(id);
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }



}

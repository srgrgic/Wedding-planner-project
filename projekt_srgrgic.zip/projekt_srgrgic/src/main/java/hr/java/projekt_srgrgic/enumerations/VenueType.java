package hr.java.projekt_srgrgic.enumerations;

import java.io.Serializable;

public enum VenueType implements Serializable {

    RESTAURANT("Restaurant", "red"),
    OUTDOOR("Na otvorenom", "green"),
    HALL("Sala", "blue"),
    OTHER("Ostalo", "yellow");

    private String venueType;
    private String labelColor;

    public String getVenueType() {
        return venueType;
    }

    public void setVenueType(String venueType) {
        this.venueType = venueType;
    }

    public String getLabelColor() {
        return labelColor;
    }

    public void setLabelColor(String labelColor) {
        this.labelColor = labelColor;
    }


    VenueType(String venueType, String labelColor) {
        this.venueType = venueType;
        this.labelColor = labelColor;
    }



    public static VenueType getVenueTypeEnum(String value) {
        VenueType venueTypeEnum = null;
        switch (value) {
            case "Restoran":
                venueTypeEnum = VenueType.RESTAURANT;
                break;
            case "Na otvorenom":
                venueTypeEnum = VenueType.OUTDOOR;
                break;
            case "Sala":
                venueTypeEnum = VenueType.HALL;
                break;
            case "Ostalo":
                venueTypeEnum = VenueType.OTHER;
                break;
        }

        return venueTypeEnum;
    }

    @Override
    public String toString() {
        return getVenueType();
    }


}

package hr.java.projekt_srgrgic.entity;

import java.time.LocalDate;

public class Reservation {

    private Long id;
    private Long venueId;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    private Long userId;
    private LocalDate date;

    public Reservation(Builder builder, Long id, Long venueShownId, LocalDate selectedDate) {
        this.id = builder.id;
        this.venueId = builder.venueId;
        this.userId=builder.userId;
        this.date = builder.date;
    }


    public static class Builder {
        public Long userId;
        private Long id;
        private Long venueId;
        private LocalDate date;

        public Builder withId(Long id) {
            this.id = id;
            return this;
        }

        public Builder withVenueId(Long venueId) {
            this.venueId = venueId;
            return this;
        }

        public Builder withUserId(Long userId) {
            this.userId = venueId;
            return this;
        }

        public Builder withDate(LocalDate date) {
            this.date = date;
            return this;
        }

        public Reservation build() {
            Reservation reservation = new Reservation();
            reservation.id=id;
            reservation.venueId=venueId;
            reservation.userId=userId;
            reservation.date=date;
            return reservation;
        }
    }


    public Long getId() {
        return id;
    }

    public Long getVenueId() {
        return venueId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setVenue(Long venueId) {
        this.venueId = venueId;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }


    public Reservation(){

    };



}


package hr.java.projekt_srgrgic.generics;

import java.util.Collections;
import java.util.List;

public class TableSorter <T extends Comparable <T>>{
    public void sort(List<T> list) {
        Collections.sort(list);
    }
}

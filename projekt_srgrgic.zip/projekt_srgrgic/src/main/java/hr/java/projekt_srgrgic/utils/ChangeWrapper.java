package hr.java.projekt_srgrgic.utils;

import hr.java.projekt_srgrgic.generics.Changes;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ChangeWrapper implements Serializable {

    List<Changes> dataChangeList;
    final Integer maxNumOfLogs = 100;

    public List<String> getStringifiedChanges() {
        List<String> changeList = new ArrayList<>();
        for (Changes dataChange : dataChangeList) {
            changeList.add(dataChange.toString());
        }
        return changeList;
    }

    public ChangeWrapper(List<Changes> dataChangeList) {
        this.dataChangeList = dataChangeList;
    }

    public List<Changes> getDataChangeList() {
        return dataChangeList;
    }

    public void setDataChangeList(List<Changes> dataChangeList) {
        this.dataChangeList = dataChangeList;
    }

    public void loadData(ChangeWrapper oldDataChangeWrapper) {
        this.dataChangeList = oldDataChangeWrapper.dataChangeList;
    }

    public void loadPreDefinedPath() {
        ChangeWrapper oldDataChangeWrapper = FileUtils.readDataChangeFromFile();
        this.dataChangeList = oldDataChangeWrapper.dataChangeList;
    }

    public void addDataChange(Changes dataChange) {
        dataChangeList.add(dataChange);
        if (dataChangeList.size() > maxNumOfLogs) dataChangeList.removeFirst();
        FileUtils.writeDataChangeToFile(this);
    }
}

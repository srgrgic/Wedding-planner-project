module hr.java.projekt_srgrgic {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.slf4j;
    requires org.controlsfx.controls;
    requires java.sql;

    exports hr.java.projekt_srgrgic;
    opens hr.java.projekt_srgrgic to javafx.fxml;
    exports hr.java.projekt_srgrgic.listcells;
    opens hr.java.projekt_srgrgic.listcells to javafx.fxml;
    exports hr.java.projekt_srgrgic.controllers to javafx.fxml;
    opens hr.java.projekt_srgrgic.controllers to javafx.fxml;
}